
#include "stdafx.h"
#include "camcommon.h"
