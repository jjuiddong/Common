#pragma once

#include <windows.h>
#include "sfml/Config.hpp"
#include "sfml/Window.hpp"
#include "sfml/Graphics/RenderWindow.hpp"


#pragma comment(lib, "sfml-system.lib")
#pragma comment(lib, "sfml-window.lib")
#pragma comment(lib, "sfml-graphics.lib")
