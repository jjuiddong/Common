#pragma once


namespace common
{

	void SetSeedId(const int seed);
	int GenerateId();

}
